import 'package:flutter/material.dart';

void main() {
  runApp(ChocolateShopWireframe());
}

class ChocolateShopWireframe extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Toko Coklat',
      theme: ThemeData(
        primarySwatch: Colors.brown,
        scaffoldBackgroundColor: Colors.grey[100],
      ),
      home: HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [
    HomeContent(),
    CategoryPage(),
    CartPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Toko Coklat'),
        backgroundColor: Colors.brown[300],
        actions: [
          IconButton(
            icon: Icon(Icons.search),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => SearchPage()),
              );
            },
          ),
          IconButton(
            icon: Icon(Icons.notifications),
            onPressed: () {},
          ),
        ],
      ),
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        selectedItemColor: Colors.brown[700],
        unselectedItemColor: Colors.grey,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Beranda'),
          BottomNavigationBarItem(icon: Icon(Icons.category), label: 'Kategori'),
          BottomNavigationBarItem(icon: Icon(Icons.shopping_cart), label: 'Keranjang'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profil'),
        ],
      ),
    );
  }
}

// Halaman Beranda
class HomeContent extends StatelessWidget {
  final List<Map<String, String>> products = [
    {
      'name': 'Dark Chocolate',
      'image': 'https://images.unsplash.com/photo-1481391319762-47dff72954d9?w=400',
    },
    {
      'name': 'Milk Chocolate',
      'image': 'https://images.unsplash.com/photo-1511381939415-e44015466834?w=400',
    },
    {
      'name': 'White Chocolate',
      'image': 'https://images.unsplash.com/photo-1620930092960-16d835eee4c6?w=400',
    },
    {
      'name': 'Truffle Chocolate',
      'image': 'https://images.unsplash.com/photo-1548907040-4baa42d10919?w=400',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Banner Section
          Container(
            width: double.infinity,
            height: 150,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              image: DecorationImage(
                image: NetworkImage('https://images.unsplash.com/photo-1481391319762-47dff72954d9?w=800'),
                fit: BoxFit.cover,
              ),
            ),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                gradient: LinearGradient(
                  colors: [Colors.black.withOpacity(0.3), Colors.transparent],
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                ),
              ),
              child: Center(
                child: Text(
                  'Promo Spesial Coklat',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
          
          SizedBox(height: 20),
          
          // Kategori Section
          Text(
            'Kategori Populer',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 10),
          
                      Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildCategoryItem('Coklat Batang', 'https://images.unsplash.com/photo-1481391319762-47dff72954d9?w=200'),
              _buildCategoryItem('Coklat Praline', 'https://images.unsplash.com/photo-1549007994-cb92caebd54b?w=200'),
              _buildCategoryItem('Coklat Truffle', 'https://images.unsplash.com/photo-1548907040-4baa42d10919?w=200'),
            ],
          ),
          
          SizedBox(height: 20),
          
          // Produk Terlaris Section
          Text(
            'Produk Terlaris',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 10),
          
          GridView.builder(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 0.8,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
            ),
            itemCount: products.length,
            itemBuilder: (context, index) {
              return GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ProductDetailPage(
                        productName: products[index]['name']!,
                        productImage: products[index]['image']!,
                      ),
                    ),
                  );
                },
                child: _buildProductCard(products[index]['name']!, products[index]['image']!),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryItem(String title, String imageUrl) {
    return Column(
      children: [
        Container(
          width: 60,
          height: 60,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.brown[300]!),
            image: DecorationImage(
              image: NetworkImage(imageUrl),
              fit: BoxFit.cover,
            ),
          ),
        ),
        SizedBox(height: 5),
        Text(
          title,
          style: TextStyle(fontSize: 12),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildProductCard(String title, String imageUrl) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.vertical(top: Radius.circular(8)),
                image: DecorationImage(
                  image: NetworkImage(imageUrl),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: TextStyle(fontWeight: FontWeight.bold)),
                Text('Rp 25.000', style: TextStyle(color: Colors.green)),
                SizedBox(height: 5),
                Row(
                  children: [
                    Icon(Icons.star, size: 16, color: Colors.orange),
                    Text('4.5', style: TextStyle(fontSize: 12)),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// Halaman Kategori
class CategoryPage extends StatelessWidget {
  final List<Map<String, String>> categories = [
    {
      'name': 'Coklat Batang',
      'count': '25 produk',
      'image': 'https://images.unsplash.com/photo-1481391319762-47dff72954d9?w=200',
    },
    {
      'name': 'Coklat Praline',
      'count': '18 produk',
      'image': 'https://images.unsplash.com/photo-1549007994-cb92caebd54b?w=200',
    },
    {
      'name': 'Coklat Truffle',
      'count': '12 produk',
      'image': 'https://images.unsplash.com/photo-1548907040-4baa42d10919?w=200',
    },
    {
      'name': 'Coklat Kacang',
      'count': '20 produk',
      'image': 'https://images.unsplash.com/photo-1511381939415-e44015466834?w=200',
    },
    {
      'name': 'Coklat Mint',
      'count': '8 produk',
      'image': 'https://images.unsplash.com/photo-1499636136210-6f4ee915583e?w=200',
    },
    {
      'name': 'Coklat Putih',
      'count': '15 produk',
      'image': 'https://images.unsplash.com/photo-1620930092960-16d835eee4c6?w=200',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Semua Kategori',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 20),
          Expanded(
            child: ListView.builder(
              itemCount: categories.length,
              itemBuilder: (context, index) {
                return _buildCategoryListItem(
                  categories[index]['name']!,
                  categories[index]['count']!,
                  categories[index]['image']!,
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryListItem(String title, String count, String imageUrl) {
    return Container(
      margin: EdgeInsets.only(bottom: 10),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: Row(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              image: DecorationImage(
                image: NetworkImage(imageUrl),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: TextStyle(fontWeight: FontWeight.bold)),
                Text(count, style: TextStyle(color: Colors.grey[600])),
              ],
            ),
          ),
          Icon(Icons.arrow_forward_ios, color: Colors.grey),
        ],
      ),
    );
  }
}

// Halaman Keranjang
class CartPage extends StatelessWidget {
  final List<Map<String, String>> cartItems = [
    {
      'name': 'Coklat Batang Premium',
      'price': 'Rp 35.000',
      'quantity': '2',
      'image': 'https://images.unsplash.com/photo-1481391319762-47dff72954d9?w=200',
    },
    {
      'name': 'Coklat Truffle Deluxe',
      'price': 'Rp 45.000',
      'quantity': '1',
      'image': 'https://images.unsplash.com/photo-1548907040-4baa42d10919?w=200',
    },
    {
      'name': 'Coklat Praline Mix',
      'price': 'Rp 28.000',
      'quantity': '3',
      'image': 'https://images.unsplash.com/photo-1549007994-cb92caebd54b?w=200',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Keranjang Belanja',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 20),
          Expanded(
            child: ListView.builder(
              itemCount: cartItems.length,
              itemBuilder: (context, index) {
                return _buildCartItem(
                  cartItems[index]['name']!,
                  cartItems[index]['price']!,
                  cartItems[index]['quantity']!,
                  cartItems[index]['image']!,
                );
              },
            ),
          ),
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.grey[300]!),
            ),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Total:', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    Text('Rp 189.000', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.green)),
                  ],
                ),
                SizedBox(height: 15),
                Container(
                  width: double.infinity,
                  height: 45,
                  decoration: BoxDecoration(
                    color: Colors.brown[300],
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Center(
                    child: Text(
                      'Checkout',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCartItem(String title, String price, String quantity, String imageUrl) {
    return Container(
      margin: EdgeInsets.only(bottom: 10),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: Row(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              image: DecorationImage(
                image: NetworkImage(imageUrl),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: TextStyle(fontWeight: FontWeight.bold)),
                Text(price, style: TextStyle(color: Colors.green)),
              ],
            ),
          ),
          Row(
            children: [
              Icon(Icons.remove_circle_outline),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 10),
                child: Text(quantity),
              ),
              Icon(Icons.add_circle_outline),
            ],
          ),
        ],
      ),
    );
  }
}

// Halaman Profil
class ProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16.0),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.grey[300]!),
            ),
            child: Column(
              children: [
                CircleAvatar(
                  radius: 40,
                  backgroundImage: NetworkImage('https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=200'),
                  backgroundColor: Colors.brown[100],
                ),
                SizedBox(height: 10),
                Text('Nurwadah', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                Text('nurwadah25@gmail.com', style: TextStyle(color: Colors.grey[600])),
              ],
            ),
          ),
          SizedBox(height: 20),
          Expanded(
            child: ListView(
              children: [
                _buildProfileMenuItem(Icons.history, 'Riwayat Pesanan'),
                _buildProfileMenuItem(Icons.favorite, 'Wishlist'),
                _buildProfileMenuItem(Icons.location_on, 'Alamat'),
                _buildProfileMenuItem(Icons.settings, 'Pengaturan'),
                _buildProfileMenuItem(Icons.help, 'Bantuan'),
                _buildProfileMenuItem(Icons.logout, 'Keluar'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileMenuItem(IconData icon, String title) {
    return Container(
      margin: EdgeInsets.only(bottom: 10),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: Colors.brown[100],
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: Colors.brown[600], size: 22),
          ),
          SizedBox(width: 15),
          Expanded(child: Text(title)),
          Icon(Icons.arrow_forward_ios, color: Colors.grey, size: 16),
        ],
      ),
    );
  }
}

// Halaman Detail Produk
class ProductDetailPage extends StatelessWidget {
  final String productName;
  final String productImage;

  ProductDetailPage({
    this.productName = 'Coklat Premium Deluxe',
    this.productImage = 'https://images.unsplash.com/photo-1481391319762-47dff72954d9?w=600',
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detail Produk'),
        backgroundColor: Colors.brown[300],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              height: 250,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: NetworkImage(productImage),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    productName,
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Rp 45.000',
                    style: TextStyle(fontSize: 20, color: Colors.green, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  Row(
                    children: [
                      Icon(Icons.star, color: Colors.orange),
                      Text('4.8 (120 review)'),
                    ],
                  ),
                  SizedBox(height: 20),
                  Text(
                    'Deskripsi Produk',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  Container(
                    width: double.infinity,
                    padding: EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.grey[100],
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.grey[300]!),
                    ),
                    child: Text(
                      'Coklat premium dengan kualitas terbaik. Dibuat dari biji kakao pilihan dengan rasa yang lezat dan tekstur yang lembut. Cocok untuk hadiah atau dinikmati sendiri.',
                      style: TextStyle(color: Colors.grey[700]),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.2),
              spreadRadius: 1,
              blurRadius: 5,
            ),
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: Container(
                height: 45,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.brown[300]!),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Center(
                  child: Text(
                    'Tambah ke Keranjang',
                    style: TextStyle(color: Colors.brown[700]),
                  ),
                ),
              ),
            ),
            SizedBox(width: 10),
            Expanded(
              child: Container(
                height: 45,
                decoration: BoxDecoration(
                  color: Colors.brown[300],
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Center(
                  child: Text(
                    'Beli Sekarang',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Halaman Pencarian
class SearchPage extends StatelessWidget {
  final List<Map<String, String>> searchResults = [
    {
      'name': 'Dark Chocolate Bar',
      'price': 'Rp 30.000',
      'image': 'https://images.unsplash.com/photo-1481391319762-47dff72954d9?w=200',
    },
    {
      'name': 'Milk Chocolate',
      'price': 'Rp 25.000',
      'image': 'https://images.unsplash.com/photo-1511381939415-e44015466834?w=200',
    },
    {
      'name': 'Chocolate Truffle',
      'price': 'Rp 45.000',
      'image': 'https://images.unsplash.com/photo-1548907040-4baa42d10919?w=200',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Container(
          height: 40,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
          ),
          child: TextField(
            decoration: InputDecoration(
              hintText: 'Cari coklat...',
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              suffixIcon: Icon(Icons.search),
            ),
          ),
        ),
        backgroundColor: Colors.brown[300],
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Pencarian Terkini',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Wrap(
              spacing: 8,
              children: [
                _buildSearchChip('coklat batang'),
                _buildSearchChip('truffle'),
                _buildSearchChip('praline'),
              ],
            ),
            SizedBox(height: 20),
            Text(
              'Rekomendasi Produk',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: searchResults.length,
                itemBuilder: (context, index) {
                  return _buildSearchResultItem(
                    searchResults[index]['name']!,
                    searchResults[index]['price']!,
                    searchResults[index]['image']!,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchResultItem(String name, String price, String imageUrl) {
    return Container(
      margin: EdgeInsets.only(bottom: 10),
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: Row(
        children: [
          Container(
            width: 70,
            height: 70,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              image: DecorationImage(
                image: NetworkImage(imageUrl),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                ),
                SizedBox(height: 5),
                Text(
                  price,
                  style: TextStyle(color: Colors.green, fontWeight: FontWeight.w600),
                ),
                SizedBox(height: 5),
                Row(
                  children: [
                    Icon(Icons.star, size: 14, color: Colors.orange),
                    SizedBox(width: 4),
                    Text('4.7', style: TextStyle(fontSize: 12)),
                  ],
                ),
              ],
            ),
          ),
          Icon(Icons.arrow_forward_ios, color: Colors.grey, size: 16),
        ],
      ),
    );
  }

  Widget _buildSearchChip(String text) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.brown[100],
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.brown[300]!),
      ),
      child: Text(text, style: TextStyle(color: Colors.brown[700])),
    );
  }
}